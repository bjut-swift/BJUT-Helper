# ch3 运输层

## 服务

为不同主机上的应用进程（应用层）之间提供逻  
辑通信  
 运输协议运行在端系统中（路由器不涉及）  
发送方：将应用报文划分为段，传向网络层  
接收方：将段重新装配为报文，传向应用层  
 应用可供使用的运输协议不止一个  
因特网：TCP和UDP

‍

依赖、强化网络层服务

‍

## 3.2 多路复用与多路分解

*家庭类比:
12个孩子向12个孩子发信
（Ann和Bill负责收发信件）
◼ Bill从邮递员处收到一批信，通过查看收信人姓名将信
件交付到其他人手中，他执行的就是一个多路分解操
作。
◼ Ann从其他人手中收集信件并交给邮递员时，她执行
的就是一个多路复用操作。*

​![image](assets/image-20241204210708-enu8881.png)​

‍

主机接收IP数据报  
 每个数据报**承载1个运输层段**  
 每个段具有源、目的端口号 （特定应用程序有周知端口号）  
 **主机使用IP地址&amp;端口号将段定向到适当的套接字**

‍

**UDP套接字由二元组标识 :(目的地IP地址，目的地端口号)**

◼当主机接收UDP段时：  
◼ 在段中检查目的地端口号  
◼ 将UDP段定向到具有该端口号的套接字  
◼具有不同源IP地址和/或源端口号的IP数据报定向到相同的套接字

‍

‍

TCP套接字由四元组标识：  
**源IP地址-源端口号-目的IP地址-目的端口号**

**Web服务器对每个连接的客户机具有不同的套接字**

‍

## Web服务器对每个连接的客户机具有不同的套接字

‍

## 3.4可靠数据传输

### 1. 数据包和序列号

* **数据包**：数据在网络中被分割成小块，称为数据包。
* **序列号**：每个数据包都有一个唯一的序列号，用于标识数据的顺序。这有助于接收方按正确的顺序重组数据。

### 2. 确认（ACK）

* **确认机制**：接收方在成功接收到数据包后，会发送一个确认消息（ACK）回发送方，表示该数据包已成功接收。
* **超时重传**：如果发送方在一定时间内未收到ACK，它会重传该数据包。

### 3. 数据完整性检查

* **校验和**：在发送数据包时，发送方计算数据的校验和，并将其附加到数据包中。接收方在接收到数据包后，重新计算校验和并与附加的校验和进行比较，检查数据是否完整且未被篡改。

### 4. 流量控制

* **流量控制**：为了防止接收方处理不过来，发送方会根据接收方的处理能力调整发送速率。这可以通过滑动窗口协议等方法实现。

### 5. 拥塞控制

* **拥塞控制**：在网络拥堵时，发送方会减少数据发送速率，以避免进一步加剧拥塞。这通常通过监测网络的延迟和数据包丢失情况来实现。

​![image](https://cbt567.oss-rg-china-mainland.aliyuncs.com/img/202412192129745.png)​

‍

‍

## `3.6 拥塞控制原理`​

表现：  
◼ 丢包 (路由器缓存区溢出)  
◼ 长时延 (路由器缓存区中排队)

# 拥塞控制的两种方法详解

## 端到端的拥塞控制

### 基本特征

1. **信息获取方式**

    * 没有从网络获得明确的拥塞反馈
    * 完全依赖端系统（发送方和接收方）自身的观察和推断
2. **拥塞检测机制**

    * 通过观察网络中的关键指标来推断拥塞状况
    * 主要观测指标：

      * 数据包传输延迟
      * 数据包丢失情况
      * 网络吞吐量变化
3. **典型实现**

    * TCP协议广泛采用这种方法
    * 主要通过以下机制实现：

      * 慢启动
      * 拥塞避免
      * 快重传
      * 快恢复

### 工作原理

* 发送方通过观察ACK返回情况
* 分析往返时间（RTT）
* 监控数据包丢失率
* 动态调整发送窗口大小

## 网络辅助的拥塞控制

### 基本特征

1. **信息获取方式**

    * 路由器主动为端系统提供拥塞反馈
    * 直接的网络层拥塞信号
2. **拥塞信号机制**

    * 使用最简单的方式：单个比特指示链路拥塞状态
    * 常见于不同网络协议：

      * SNA（系统网络架构）
      * DECnet
      * TCP/IP ECN（显式拥塞通知）
      * ATM（异步传输模式）
3. **控制方法**

    * 路由器直接告知发送方降低发送速率
    * 提供精确的网络拥塞状态信息

### 工作原理

* 网络设备（路由器）实时监控链路负载
* 当链路接近饱和时，设置拥塞标志
* 通过特定信号通知发送方调整发送速率

## 两种方法的对比

<div>
<pre class="font-styrene border-border-100/50 overflow-x-scroll whitespace-nowrap rounded border-[0.5px] shadow-[0_2px_12px_rgba(0,0,0,0.05)]"><table class="bg-bg-100 min-w-full border-separate border-spacing-0 text-sm leading-[1.88888]"><thead class="border-b-border-100/50 border-b-[0.5px] text-left"><tr class="[tbody&gt;&amp;]:odd:bg-bg-500/10"><th class="text-text-000 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] font-400 px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">特征</th><th class="text-text-000 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] font-400 px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">端到端拥塞控制</th><th class="text-text-000 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] font-400 px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">网络辅助拥塞控制</th></tr></thead><tbody><tr class="[tbody&gt;&amp;]:odd:bg-bg-500/10"><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">信息来源</td><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">端系统自身观察</td><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">网络设备直接提供</td></tr><tr class="[tbody&gt;&amp;]:odd:bg-bg-500/10"><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">实现复杂度</td><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">相对复杂</td><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">相对简单</td></tr><tr class="[tbody&gt;&amp;]:odd:bg-bg-500/10"><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">适用协议</td><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">TCP</td><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">SNA, DECnet, ECN</td></tr><tr class="[tbody&gt;&amp;]:odd:bg-bg-500/10"><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">反馈精确度</td><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">间接推断</td><td class="border-t-border-100/50 [&amp;:not(:first-child)]:-x-[hsla(var(--border-100) / 0.5)] border-t-[0.5px] px-2 [&amp;:not(:first-child)]:border-l-[0.5px]">直接指示</td></tr></tbody></table></pre>
</div>

## 两种方法的对比

‍

## 优缺点分析

### 端到端拥塞控制

**优点**：

* 不需要网络设备额外支持
* 适应性强
* 可以应用于各种网络环境

**缺点**：

* 反应可能较慢
* 依赖间接推断
* 可能出现滞后

### 网络辅助拥塞控制

**优点**：

* 反馈精确直接
* 网络设备可以实时告知拥塞情况
* 控制更加精准

**缺点**：

* 需要网络设备支持
* 实现成本较高
* 可能增加网络复杂度

## 实际应用思考

在实际网络中，这两种方法often是互补的。现代网络协议倾向于结合两种方法的优点，以获得更好的拥塞控制效果。

## 结语

理解拥塞控制不仅仅是技术细节，更是网络资源合理利用的艺术。通过巧妙的机制，我们可以让数据在网络中高效、公平地传输。

希望这个详细的解释能帮助你深入理解拥塞控制的两类方法。如果你有任何疑问，随时可以问我！
